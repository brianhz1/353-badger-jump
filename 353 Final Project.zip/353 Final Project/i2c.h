/*
 * i2c.h
 *
 *  Created on: May 4, 2023
 *      Author: Brian Zhang
 */

#ifndef I2C_H_
#define I2C_H_

#include <main.h>
#include "math.h"

#define OPT3001_ADDRESS 0x44

#define OPT_INTERRUPT_PIN 11
#define RESULT_REG 0x00
#define CONFIG_REG 0x01
#define LOWLIMIT_REG 0x02
#define HIGHLIMIT_REG 0x03
#define MANUFACTUREID_REG 0x7E
#define DEVICEID_REG 0x7F

/**********************************************************************************************
 * Initializes i2c for communication with opt3001
 **********************************************************************************************/
void i2c_init(void);

/**********************************************************************************************
 * Reads a 16 bit data word over i2c
 **********************************************************************************************/
uint16_t i2c_read_16(uint8_t slave_address, uint8_t dev_address);

/**********************************************************************************************
 * Writes a 16 bit data word over i2c
 **********************************************************************************************/
void i2c_write_16(uint8_t slave_address, uint8_t dev_address, uint16_t data);

/******************************************************************************
 * Initialize the opt3001 ambient light sensor on the MKII and the i2c
 ******************************************************************************/
void light_sensor_init(void);
/******************************************************************************
 * Returns the current ambient light in lux
 ******************************************************************************/
float light_sensor_read_lux(void);

#endif /* I2C_H_ */
