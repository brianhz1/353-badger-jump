/*
 * task_manage_game.h
 *
 *  Created on: May 3, 2023
 *      Author: bzhan
 */

#ifndef TASK_MANAGE_GAME_H_
#define TASK_MANAGE_GAME_H_

#include <main.h>

#define DARK_MODE_LUX_THRESHOLD 40
#define LIGHT_BACKGROUND_COLOR 0xFFFF
#define DARK_BACKGROUND_COLOR 0x0000

extern TaskHandle_t Task_start_game_handle;
extern bool game_running; // global variable which controls if game is running
int background_color;

/*****************************************************************************
 * Checks for when s2 is pressed to start the game
 ****************************************************************************/
void Task_start_game(void *pvParameters);

#endif /* TASK_MANAGE_GAME_H_ */
